# -*- coding: utf-8 -*-
################################################################################
#
#    Dot BD Solutions Limited
#    Copyright (C) 2025-TODAY Dot BD Solutions Limited.
#
################################################################################
import logging
import pytz
from datetime import datetime, timedelta
from odoo import fields, models, api

_logger = logging.getLogger(__name__)


class HrAttendance(models.Model):
    """Inherit the module to add late check-in tracking with tolerance"""
    _inherit = 'hr.attendance'

    late_check_in = fields.Integer(
        string="Actual Late Time (Minutes)",
        compute="_compute_late_check_in",
        help="This shows the actual duration of the employee's tardiness (without tolerance).",
        store=True)

    tolerance_late_time = fields.Integer(
        string="Counted Late Time (Minutes)",
        compute="_compute_tolerance_late_time",
        help="Late time after applying tolerance settings. 0 means within tolerance limit.",
        store=True)

    is_within_tolerance = fields.Boolean(
        string="Within Tolerance",
        compute="_compute_tolerance_late_time",
        help="True if the employee is within the late tolerance limit.",
        store=True)

    late_check_in_id = fields.Many2one(
        'late.check.in',
        string="Late Check-in Record",
        help="Related late check-in record if created")

    # ZK Machine Integration
    zk_punch_ids = fields.One2many(
        'zk.machine.attendance', 'hr_attendance_id',
        string='Device Punches',
        help='Raw punch records from biometric device that contributed to this attendance')

    zk_punch_count = fields.Integer(
        string='Punch Count',
        compute='_compute_zk_punch_count',
        store=True,
        help='Number of device punches linked to this attendance')

    attendance_source = fields.Selection([
        ('biometric', 'Biometric Device'),
        ('manual', 'Manual Entry'),
        ('system', 'System Generated')
    ], string='Attendance Source', compute='_compute_attendance_source', store=True,
       help='Source of this attendance record')

    @api.depends('zk_punch_ids')
    def _compute_zk_punch_count(self):
        """Count the number of ZK punches linked to this attendance"""
        for rec in self:
            rec.zk_punch_count = len(rec.zk_punch_ids)

    @api.depends('zk_punch_ids')
    def _compute_attendance_source(self):
        """Determine the source of attendance record"""
        for rec in self:
            if rec.zk_punch_ids:
                rec.attendance_source = 'biometric'
            else:
                rec.attendance_source = 'manual'

    @api.depends('check_in', 'employee_id.resource_calendar_id.attendance_ids')
    def _compute_late_check_in(self):
        """Calculate actual late check-in minutes without applying tolerance."""
        for rec in self:
            rec.late_check_in = 0
            if not rec.check_in or not rec.employee_id:
                continue

            # Get resource calendar from employee or contract
            calendar = None
            # Try to get calendar from current contract
            try:
                if hasattr(rec.employee_id, '_get_contracts'):
                    contracts = rec.employee_id._get_contracts(rec.check_in.date())
                    if contracts and rec.employee_id.id in contracts:
                        contract_versions = contracts[rec.employee_id.id]
                        if contract_versions and hasattr(contract_versions, 'resource_calendar_id'):
                            calendar = contract_versions.resource_calendar_id
            except Exception as e:
                _logger.debug("Could not get contract calendar for %s: %s", rec.employee_id.name, e)
            
            if not calendar:
                calendar = rec.employee_id.resource_calendar_id
            if not calendar:
                calendar = rec.employee_id.company_id.resource_calendar_id

            if not calendar:
                continue

            # Convert check_in using the calendar's timezone (same tz as hour_from).
            # In Odoo 19 _get_tz() was updated to put calendar.tz first for this
            # exact reason. We replicate that priority here so the weekday and the
            # start-time comparison are both in the schedule's reference frame.
            cal_tz_name = (calendar.tz
                           or rec.employee_id.tz
                           or rec.employee_id.company_id.resource_calendar_id.tz
                           or 'UTC')
            tz_obj = pytz.timezone(cal_tz_name) if cal_tz_name in pytz.all_timezones else pytz.utc
            dt_local = pytz.utc.localize(rec.check_in).astimezone(tz_obj)
            local_weekday = str(dt_local.weekday())

            # Find the earliest start time among all schedule lines for this weekday.
            # Using the earliest start handles both morning-only and full-day schedule types.
            day_schedules = [s for s in calendar.attendance_ids
                             if s.dayofweek == local_weekday]
            if not day_schedules:
                continue
            schedule = min(day_schedules, key=lambda s: s.hour_from)

            str_time = dt_local.strftime("%H:%M")
            check_in_date = datetime.strptime(str_time, "%H:%M").time()
            start_date = datetime.strptime(
                '{0:02.0f}:{1:02.0f}'.format(*divmod(
                    schedule.hour_from * 60, 60)), "%H:%M").time()

            check_in_td = timedelta(hours=check_in_date.hour, minutes=check_in_date.minute)
            start_date_td = timedelta(hours=start_date.hour, minutes=start_date.minute)

            if check_in_td > start_date_td:
                final = check_in_td - start_date_td
                rec.late_check_in = int(final.total_seconds() / 60)

    @api.depends('late_check_in')
    def _compute_tolerance_late_time(self):
        """Calculate late time after applying tolerance settings."""
        for rec in self:
            # Get tolerance parameter from system configuration
            minutes_after = int(self.env['ir.config_parameter'].sudo().get_param(
                'dotbd_hr_zk_attendance_suite.late_check_in_after', default=0))

            if rec.late_check_in > minutes_after:
                rec.tolerance_late_time = rec.late_check_in - minutes_after
                rec.is_within_tolerance = False
            else:
                rec.tolerance_late_time = 0
                rec.is_within_tolerance = True

    @api.model
    def create_late_check_in_records(self):
        """Function creates records in late.check.in model for employees who were late
        This is called by cron job or manually"""
        max_limit = int(self.env['ir.config_parameter'].sudo().get_param(
            'dotbd_hr_zk_attendance_suite.maximum_minutes', default=240))

        enable_penalties = self.env['ir.config_parameter'].sudo().get_param(
            'dotbd_hr_zk_attendance_suite.enable_late_penalties', default='True') in ('True', 'true', '1', True)

        if not enable_penalties:
            return

        # Get existing late check-in records
        existing_late_records = self.env['late.check.in'].sudo().search([])
        existing_attendance_ids = set(existing_late_records.mapped('attendance_id.id'))

        # Get all attendance records without late check-in record
        attendance_records = self.sudo().search([
            ('check_in', '!=', False),
            ('late_check_in', '>', 0),
        ])

        for rec in attendance_records:
            # Skip if within tolerance
            if rec.is_within_tolerance:
                continue

            # Skip if exceeds maximum limit (considered absent instead of late)
            if max_limit > 0 and rec.late_check_in > max_limit:
                continue

            record_data = {
                'employee_id': rec.employee_id.id,
                'late_minutes': rec.tolerance_late_time,
                'actual_late_minutes': rec.late_check_in,
                'date': rec.check_in.date(),
                'attendance_id': rec.id,
            }

            if rec.id not in existing_attendance_ids:
                # Create new late check-in record
                late_record = self.env['late.check.in'].sudo().create(record_data)
                rec.late_check_in_id = late_record.id
            else:
                # Update existing record
                existing_record = existing_late_records.filtered(
                    lambda x: x.attendance_id.id == rec.id
                )
                if existing_record:
                    existing_record.write(record_data)

    @api.model
    def late_check_in_records(self):
        """Alias method for backward compatibility with employee_late_check_in module
        Calls create_late_check_in_records() method"""
        return self.create_late_check_in_records()

    def unlink(self):
        """Override the unlink method to delete corresponding records in late.check.in model"""
        late_records_to_delete = self.env['late.check.in'].sudo().search([
            ('attendance_id', 'in', self.ids)
        ])
        late_records_to_delete.unlink()
        return super(HrAttendance, self).unlink()
